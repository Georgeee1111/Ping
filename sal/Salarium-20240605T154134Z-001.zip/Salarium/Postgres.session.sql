DELETE FROM public.transaction
